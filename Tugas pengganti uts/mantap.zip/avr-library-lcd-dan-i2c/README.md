Tugas 2 Embeded System - Fasilkom UI 2014/2015
==============================================
