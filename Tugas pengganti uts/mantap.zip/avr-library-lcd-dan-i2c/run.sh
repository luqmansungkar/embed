make clean
sleep 1
make all
sleep 1
make program
