#ifndef _I2C_MASTER_CONF_
#define _I2C_MASTER_CONF_

#define I2C_BUS_FREQ        50000UL

#endif
